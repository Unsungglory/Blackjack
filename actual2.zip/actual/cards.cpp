#include "cards.h"
#include<vector>
#include<iostream>
#include<string>

CARD::CARD() // Defualt Constructor
{

}

CARD::CARD(std::string v, std::string s)
{
	value=v;
	suite=s;
}

int CARD::get_numeric_value()
{
	std::string test = value;
	if (test == "1")
		return 1;
	else if (test == "2")
		return 2;
	else if (test == "3")
		return 3;
	else if (test == "4")
		return 4;
	else if (test == "5")
		return 5;
	else if (test == "6")
		return 6;
	else if (test == "7")
		return 7;
	else if (test == "8")
		return 8;
	else if (test == "9")
		return 9;
	else if (test == "10")
		return 10;
	else if (test == "Jack")
		return 10;
	else if (test == "Queen")
		return 10;
	else if (test == "King")
		return 10;
	else if (test == "Ace")
		return 11;
	else 
		return 0;
}

std::string CARD::get_value()
{
	return value;
}

std::string CARD::get_suite()
{
	return suite;
}

void CARD::set_value(std::string s)
{
  value = s;
}

void CARD::set_suite(std::string s)
{
  suite = s;
}


